##### functions to run cla_secsse_ml ============================================================================

#---------- function for all transitions between states allowed

secsse_run <- function(tree, traits, num_concealed_states, dependency, inheritance, transition, diff.conceal,
                       init_lambda, init_mu, init_q, initparsopt,
                       parsfix, sampling_fraction,
                       num_threads,
                       save_dir_idpars, save_dir_secsse) {
  stopifnot(dependency %in% c("ETD", "CTD", "CR"))
  stopifnot(inheritance %in% c("dual_inheritance", "single_inheritance", "dual_symmetric_transition", "dual_asymmetric_transition"))
  stopifnot(transition %in% c("ER", "SYM", "SYM_cons_dd_pd", "SYM_3_rates", "SYM_cons_dd_pd_3_rates", "SYM_2_rates", "SYM_2_rates_plet", "SYM_2_rates_sal", "ARD"))
  stopifnot(diff.conceal %in% c("TRUE", "FALSE"))
  stopifnot(initparsopt %in% c("opt", "opt_x2", "opt_x0-5", "opt_mu0-02"))
  stopifnot(parsfix %in% c("none", "lambda", "mu"))

  idparslist <- list()
  if (is.matrix(traits)) {
    traits <- traits[, 1]
  }

  num_states <- length(unique(traits))
  ly <- length(sort(unique(traits))) * 2 * num_concealed_states
  d <- ly / 2
  id_rates <- c(1:num_concealed_states)

  ### create lambda and mu matrix ---------------------------------------------------
  # lambda matrix
  idparslist[[1]] <- matrix(0, ncol = d, nrow = 4)
  rownames(idparslist[[1]]) <- c(
    "dual_inheritance",
    "single_inheritance",
    "dual_symmetric_transition",
    "dual_asymmetric_transition"
  )

  # mu matrix
  idparslist[[2]] <- (d + 1):ly

  ### dependency ---------------------------------------------------------------------
  if (dependency == "ETD") {
    ### lambda -----------------------------------------------------------------------
    if (inheritance == "dual_inheritance") {
      idparslist[[1]][1, ] <- rep(id_rates, times = num_concealed_states)
    }
    if (inheritance == "single_inheritance") {
      idparslist[[1]][2, ] <- rep(id_rates, times = num_concealed_states)
    }
    if (inheritance == "dual_symmetric_transition") {
      idparslist[[1]][3, ] <- rep(id_rates, times = num_concealed_states)
    }
    if (inheritance == "dual_asymmetric_transition") {
      idparslist[[1]][4, ] <- rep(id_rates, times = num_concealed_states)
    }
    ### mu ---------------------------------------------------------------------------
    idparslist[[2]][] <- rep(id_rates + length(id_rates), times = num_concealed_states)
  }

  ### dependency ---------------------------------------------------------------------
  if (dependency == "CTD") {
    ### lambda -----------------------------------------------------------------------
    if (inheritance == "dual_inheritance") {
      idparslist[[1]][1, ] <- rep(id_rates, each = num_concealed_states)
    }
    if (inheritance == "single_inheritance") {
      idparslist[[1]][2, ] <- rep(id_rates, each = num_concealed_states)
    }
    if (inheritance == "dual_symmetric_transition") {
      idparslist[[1]][3, ] <- rep(id_rates, each = num_concealed_states)
    }
    if (inheritance == "dual_asymmetric_transition") {
      idparslist[[1]][4, ] <- rep(id_rates, each = num_concealed_states)
    }
    ### mu ---------------------------------------------------------------------------
    idparslist[[2]][] <- rep(id_rates + length(id_rates), each = num_concealed_states)
  }

  ### dependency ---------------------------------------------------------------------
  if (dependency == "CR") {
    ### lambda -----------------------------------------------------------------------
    if (inheritance == "dual_inheritance") {
      idparslist[[1]][1, ] <- rep(1, times = num_concealed_states)
    }
    if (inheritance == "single_inheritance") {
      idparslist[[1]][2, ] <- rep(1, times = num_concealed_states)
    }
    if (inheritance == "dual_symmetric_transition") {
      idparslist[[1]][3, ] <- rep(1, times = num_concealed_states)
    }
    if (inheritance == "dual_asymmetric_transition") {
      idparslist[[1]][4, ] <- rep(1, times = num_concealed_states)
    }
    ### mu ---------------------------------------------------------------------------
    idparslist[[2]][] <- rep(2, times = num_concealed_states)
  }

  ### create and fill Q matrix with Equal Rate transition pattern --------------------
  if (transition == "ER") {
    # create the q matrix
    d <- max(id_rates)
    counter <- (max(idparslist[[1]], idparslist[[2]]) + 1)
    masterBlock <- matrix(counter, ncol = d, nrow = d, byrow = TRUE)
    diag(masterBlock) <- NA

    ### concealed state rates different -----------------------------------------------
    if (diff.conceal == TRUE && all(floor(masterBlock) == masterBlock, na.rm = TRUE) == FALSE) {
      # do something... maybe...
      integersmasterBlock <- floor(masterBlock)
      factorBlock <- signif(masterBlock - integersmasterBlock,
        digits = 2
      )
      factorstoExpand <- unique(sort(c(factorBlock)))
      factorstoExpand <- factorstoExpand[factorstoExpand > 0]
      newshareFac <- (max(factorstoExpand * 10) + 1):(max(factorstoExpand * 10) + length(factorstoExpand))
      newshareFac <- newshareFac / 10
      for (iii in seq_along(newshareFac)) {
        factorBlock[which(factorBlock == factorstoExpand[iii])] <- newshareFac[iii]
      }

      # create defferent id rates for concealed states
      ntraits <- length(sort(unique(traits)))
      uniqParQ <- sort(unique(c(floor(masterBlock))))
      uniqParQ2 <- uniqParQ[which(uniqParQ > 0)]
      concealnewQ <- (max(uniqParQ2) + 1):(max(uniqParQ2) + length(uniqParQ2))
      for (iii in seq_along(concealnewQ)) {
        integersmasterBlock[which(integersmasterBlock == uniqParQ2[iii])] <- concealnewQ[iii]
      }
      concealnewQMatr <- integersmasterBlock + factorBlock

      # fill the q matrix
      Q <- NULL
      for (i in 1:ntraits) {
        Qrow <- NULL
        for (ii in 1:ntraits) {
          entry <- masterBlock[i, ii]
          if (is.na(entry)) {
            Qrow <- cbind(Qrow, masterBlock)
          } else {
            entry <- concealnewQMatr[i, ii]
            outDiagBlock <- matrix(0,
              ncol = ntraits,
              nrow = ntraits, byrow = TRUE
            )
            diag(outDiagBlock) <- entry
            Qrow <- cbind(Qrow, outDiagBlock)
          }
        }
        Q <- rbind(Q, Qrow)
      }
    }

    ### concealed state rates not different ------------------------------------------
    else {
      # create similar id rates for concealed states
      ntraits <- length(sort(unique(traits)))
      uniqParQ <- sort(unique(c(masterBlock)))
      uniqParQ2 <- uniqParQ[which(uniqParQ > 0)]
      concealnewQ <- (max(uniqParQ2) + 1):(max(uniqParQ2) + length(uniqParQ2))
      concealnewQMatr <- masterBlock
      for (I in seq_along(uniqParQ2)) {
        uniqParQ2
        concealnewQMatr[concealnewQMatr == uniqParQ2[I]] <- concealnewQ[I]
      }

      # fill the q matrix
      Q <- NULL
      for (i in 1:ntraits) {
        Qrow <- NULL
        for (ii in 1:ntraits) {
          entry <- masterBlock[i, ii]
          if (is.na(entry)) {
            Qrow <- cbind(Qrow, masterBlock)
          } else {
            if (diff.conceal == TRUE) {
              entry <- concealnewQMatr[i, ii]
            }
            outDiagBlock <- matrix(0,
              ncol = ntraits,
              nrow = ntraits, byrow = TRUE
            )
            diag(outDiagBlock) <- entry
            Qrow <- cbind(Qrow, outDiagBlock)
          }
        }
        Q <- rbind(Q, Qrow)
      }
    }
  }

  ### create and fill Q matrix with symmetric transition pattern --------------------
  if (transition == "SYM") {
    # create the q matrix
    d <- max(id_rates)
    masterBlock <- matrix(NA, ncol = d, nrow = d, byrow = TRUE)
    # counter for continuous values
    counter <- (max(idparslist[[1]], idparslist[[2]]) + 1)
    # fill in the upper part of the matrix with continuous values
    for (i in 1:d) {
      for (j in 1:d) {
        if (i < j) { # replace values above diag by those from below
          masterBlock[i, j] <- counter
          counter <- counter + 1
        }
      }
    }
    # apply symmetry: masterBlock[i, j] = masterBlock[j, i]
    for (i in 1:d) {
      for (j in 1:d) {
        if (i > j) {
          masterBlock[i, j] <- masterBlock[j, i]
        }
      }
    }

    diag(masterBlock) <- NA

    ### concealed state rates different -----------------------------------------------
    if (diff.conceal == TRUE && all(floor(masterBlock) == masterBlock, na.rm = TRUE) == FALSE) {
      # do something... maybe...
      integersmasterBlock <- floor(masterBlock)
      factorBlock <- signif(masterBlock - integersmasterBlock,
        digits = 2
      )
      factorstoExpand <- unique(sort(c(factorBlock)))
      factorstoExpand <- factorstoExpand[factorstoExpand > 0]
      newshareFac <- (max(factorstoExpand * 10) + 1):(max(factorstoExpand * 10) + length(factorstoExpand))
      newshareFac <- newshareFac / 10
      for (iii in seq_along(newshareFac)) {
        factorBlock[which(factorBlock == factorstoExpand[iii])] <- newshareFac[iii]
      }

      # create defferent id rates for concealed states
      ntraits <- length(sort(unique(traits)))
      uniqParQ <- sort(unique(c(floor(masterBlock))))
      uniqParQ2 <- uniqParQ[which(uniqParQ > 0)]
      concealnewQ <- (max(uniqParQ2) + 1):(max(uniqParQ2) + length(uniqParQ2))
      for (iii in seq_along(concealnewQ)) {
        integersmasterBlock[which(integersmasterBlock == uniqParQ2[iii])] <- concealnewQ[iii]
      }
      concealnewQMatr <- integersmasterBlock + factorBlock

      # fill the q matrix
      Q <- NULL
      for (i in 1:ntraits) {
        Qrow <- NULL
        for (ii in 1:ntraits) {
          entry <- masterBlock[i, ii]
          if (is.na(entry)) {
            Qrow <- cbind(Qrow, masterBlock)
          } else {
            entry <- concealnewQMatr[i, ii]
            outDiagBlock <- matrix(0,
              ncol = ntraits,
              nrow = ntraits, byrow = TRUE
            )
            diag(outDiagBlock) <- entry
            Qrow <- cbind(Qrow, outDiagBlock)
          }
        }
        Q <- rbind(Q, Qrow)
      }
    }

    ### concealed state rates not different ------------------------------------------
    else {
      # create similar id rates for concealed states
      ntraits <- length(sort(unique(traits)))
      uniqParQ <- sort(unique(c(masterBlock)))
      uniqParQ2 <- uniqParQ[which(uniqParQ > 0)]
      concealnewQ <- (max(uniqParQ2) + 1):(max(uniqParQ2) + length(uniqParQ2))
      concealnewQMatr <- masterBlock
      for (I in seq_along(uniqParQ2)) {
        uniqParQ2
        concealnewQMatr[concealnewQMatr == uniqParQ2[I]] <- concealnewQ[I]
      }

      # fill the q matrix
      Q <- NULL
      for (i in 1:ntraits) {
        Qrow <- NULL
        for (ii in 1:ntraits) {
          entry <- masterBlock[i, ii]
          if (is.na(entry)) {
            Qrow <- cbind(Qrow, masterBlock)
          } else {
            if (diff.conceal == TRUE) {
              entry <- concealnewQMatr[i, ii]
            }
            outDiagBlock <- matrix(0,
              ncol = ntraits,
              nrow = ntraits, byrow = TRUE
            )
            diag(outDiagBlock) <- entry
            Qrow <- cbind(Qrow, outDiagBlock)
          }
        }
        Q <- rbind(Q, Qrow)
      }
    }
  }

  ### create and fill Q matrix with Symmetric transition pattern with 3 transition rates -------------
  if (transition == "SYM_3_rates") {
    # create the q matrix
    d <- max(id_rates)
    masterBlock <- matrix(NA, ncol = d, nrow = d, byrow = TRUE)
    # counter for continuous values
    counter <- (max(idparslist[[1]], idparslist[[2]]) + 1)
    # list of transitions sharing the same values
    linked_indices <- list(
      group1 = list(c(1, 2), c(1, 4), c(1, 5)), # bi<->dd, bi<->pd, bi<->vi,
      group2 = list(c(1, 3), c(3, 4)), # bi<->f-bi and pd<->f-bi
      group3 = list(c(2, 3), c(2, 4), c(2, 5), c(3, 5), c(4, 5)) # dd<->f-bi, dd<->pd, dd<->vi, f-bi<->vi, pd<->vi
    )
    # assign values to the groups of transitions
    group_values <- list()
    for (g in seq_along(linked_indices)) {
      for (pair in linked_indices[[g]]) {
        i <- pair[1]
        j <- pair[2]
        masterBlock[i, j] <- counter
      }
      group_values[[g]] <- counter
      counter <- counter + 1
    }
    # fill in the upper part of the matrix with continuous values
    for (i in 1:d) {
      for (j in 1:d) {
        if (i < j && is.na(masterBlock[i, j])) {
          masterBlock[i, j] <- counter
          counter <- counter + 1
        }
      }
    }
    # apply symmetry: masterBlock[i, j] = masterBlock[j, i]
    for (i in 1:d) {
      for (j in 1:d) {
        if (i > j) {
          masterBlock[i, j] <- masterBlock[j, i]
        }
      }
    }

    diag(masterBlock) <- NA

    ### concealed state rates different -----------------------------------------------
    if (diff.conceal == TRUE && all(floor(masterBlock) == masterBlock, na.rm = TRUE) == FALSE) {
      # do something... maybe...
      integersmasterBlock <- floor(masterBlock)
      factorBlock <- signif(masterBlock - integersmasterBlock,
        digits = 2
      )
      factorstoExpand <- unique(sort(c(factorBlock)))
      factorstoExpand <- factorstoExpand[factorstoExpand > 0]
      newshareFac <- (max(factorstoExpand * 10) + 1):(max(factorstoExpand * 10) + length(factorstoExpand))
      newshareFac <- newshareFac / 10
      for (iii in seq_along(newshareFac)) {
        factorBlock[which(factorBlock == factorstoExpand[iii])] <- newshareFac[iii]
      }

      # create defferent id rates for concealed states
      ntraits <- length(sort(unique(traits)))
      uniqParQ <- sort(unique(c(floor(masterBlock))))
      uniqParQ2 <- uniqParQ[which(uniqParQ > 0)]
      concealnewQ <- (max(uniqParQ2) + 1):(max(uniqParQ2) + length(uniqParQ2))
      for (iii in seq_along(concealnewQ)) {
        integersmasterBlock[which(integersmasterBlock == uniqParQ2[iii])] <- concealnewQ[iii]
      }
      concealnewQMatr <- integersmasterBlock + factorBlock

      # fill the q matrix
      Q <- NULL
      for (i in 1:ntraits) {
        Qrow <- NULL
        for (ii in 1:ntraits) {
          entry <- masterBlock[i, ii]
          if (is.na(entry)) {
            Qrow <- cbind(Qrow, masterBlock)
          } else {
            entry <- concealnewQMatr[i, ii]
            outDiagBlock <- matrix(0,
              ncol = ntraits,
              nrow = ntraits, byrow = TRUE
            )
            diag(outDiagBlock) <- entry
            Qrow <- cbind(Qrow, outDiagBlock)
          }
        }
        Q <- rbind(Q, Qrow)
      }
    }

    ### concealed state rates not different ------------------------------------------
    else {
      # create similar id rates for concealed states
      ntraits <- length(sort(unique(traits)))
      uniqParQ <- sort(unique(c(masterBlock)))
      uniqParQ2 <- uniqParQ[which(uniqParQ > 0)]
      concealnewQ <- (max(uniqParQ2) + 1):(max(uniqParQ2) + length(uniqParQ2))
      concealnewQMatr <- masterBlock
      for (I in seq_along(uniqParQ2)) {
        uniqParQ2
        concealnewQMatr[concealnewQMatr == uniqParQ2[I]] <- concealnewQ[I]
      }

      # fill the q matrix
      Q <- NULL
      for (i in 1:ntraits) {
        Qrow <- NULL
        for (ii in 1:ntraits) {
          entry <- masterBlock[i, ii]
          if (is.na(entry)) {
            Qrow <- cbind(Qrow, masterBlock)
          } else {
            if (diff.conceal == TRUE) {
              entry <- concealnewQMatr[i, ii]
            }
            outDiagBlock <- matrix(0,
              ncol = ntraits,
              nrow = ntraits, byrow = TRUE
            )
            diag(outDiagBlock) <- entry
            Qrow <- cbind(Qrow, outDiagBlock)
          }
        }
        Q <- rbind(Q, Qrow)
      }
    }
  }

  ### create and fill Q matrix with symmetric transition pattern constrained dd_pd -------------
  if (transition == "SYM_cons_dd_pd") {
    # create the q matrix
    d <- max(id_rates)
    masterBlock <- matrix(NA, ncol = d, nrow = d, byrow = TRUE)
    # counter for continuous values
    counter <- (max(idparslist[[1]], idparslist[[2]]) + 1)
    # fill in the upper part of the matrix with continuous values
    for (i in 1:d) {
      for (j in 1:d) {
        # Skip the specific cell [2,4]
        if (i < j && !(i == 2 && j == 4)) {
          masterBlock[i, j] <- counter
          counter <- counter + 1
        }
      }
    }
    # apply symmetry: masterBlock[i, j] = masterBlock[j, i]
    for (i in 1:d) {
      for (j in 1:d) {
        if (i > j) {
          masterBlock[i, j] <- masterBlock[j, i]
        }
      }
    }

    diag(masterBlock) <- NA

    ### concealed state rates different -----------------------------------------------
    if (diff.conceal == TRUE && all(floor(masterBlock) == masterBlock, na.rm = TRUE) == FALSE) {
      # do something... maybe...
      integersmasterBlock <- floor(masterBlock)
      factorBlock <- signif(masterBlock - integersmasterBlock,
        digits = 2
      )
      factorstoExpand <- unique(sort(c(factorBlock)))
      factorstoExpand <- factorstoExpand[factorstoExpand > 0]
      newshareFac <- (max(factorstoExpand * 10) + 1):(max(factorstoExpand * 10) + length(factorstoExpand))
      newshareFac <- newshareFac / 10
      for (iii in seq_along(newshareFac)) {
        factorBlock[which(factorBlock == factorstoExpand[iii])] <- newshareFac[iii]
      }

      # create defferent id rates for concealed states
      ntraits <- length(sort(unique(traits)))
      uniqParQ <- sort(unique(c(floor(masterBlock))))
      uniqParQ2 <- uniqParQ[which(uniqParQ > 0)]
      concealnewQ <- (max(uniqParQ2) + 1):(max(uniqParQ2) + length(uniqParQ2))
      for (iii in seq_along(concealnewQ)) {
        integersmasterBlock[which(integersmasterBlock == uniqParQ2[iii])] <- concealnewQ[iii]
      }
      concealnewQMatr <- integersmasterBlock + factorBlock

      # fill the q matrix
      Q <- NULL
      for (i in 1:ntraits) {
        Qrow <- NULL
        for (ii in 1:ntraits) {
          entry <- masterBlock[i, ii]
          if (is.na(entry)) {
            Qrow <- cbind(Qrow, masterBlock)
          } else {
            entry <- concealnewQMatr[i, ii]
            outDiagBlock <- matrix(0,
              ncol = ntraits,
              nrow = ntraits, byrow = TRUE
            )
            diag(outDiagBlock) <- entry
            Qrow <- cbind(Qrow, outDiagBlock)
          }
        }
        Q <- rbind(Q, Qrow)
      }
    }

    ### concealed state rates not different ------------------------------------------
    else {
      # create similar id rates for concealed states
      ntraits <- length(sort(unique(traits)))
      uniqParQ <- sort(unique(c(masterBlock)))
      uniqParQ2 <- uniqParQ[which(uniqParQ > 0)]
      concealnewQ <- (max(uniqParQ2) + 1):(max(uniqParQ2) + length(uniqParQ2))
      concealnewQMatr <- masterBlock
      for (I in seq_along(uniqParQ2)) {
        uniqParQ2
        concealnewQMatr[concealnewQMatr == uniqParQ2[I]] <- concealnewQ[I]
      }

      # fill the q matrix
      Q <- NULL
      for (i in 1:ntraits) {
        Qrow <- NULL
        for (ii in 1:ntraits) {
          entry <- masterBlock[i, ii]
          if (is.na(entry)) {
            Qrow <- cbind(Qrow, masterBlock)
          } else {
            if (diff.conceal == TRUE) {
              entry <- concealnewQMatr[i, ii]
            }
            outDiagBlock <- matrix(0,
              ncol = ntraits,
              nrow = ntraits, byrow = TRUE
            )
            diag(outDiagBlock) <- entry
            Qrow <- cbind(Qrow, outDiagBlock)
          }
        }
        Q <- rbind(Q, Qrow)
      }
    }
  }

  ### create and fill Q matrix with symmetric transition pattern constrained dd-pd and 3 rates -------------
  if (transition == "SYM_cons_dd_pd_3_rates") {
    # create the q matrix
    d <- max(id_rates)
    masterBlock <- matrix(NA, ncol = d, nrow = d, byrow = TRUE)
    # counter for continuous values
    counter <- (max(idparslist[[1]], idparslist[[2]]) + 1)
    # list of transitions sharing the same values
    linked_indices <- list(
      group1 = list(c(1, 2), c(1, 4), c(1, 5)), # bi<->dd, bi<->pd, bi<->vi,
      group2 = list(c(1, 3), c(3, 4)), # bi<->f-bi and pd<->f-bi
      group3 = list(c(2, 3), c(2, 4), c(2, 5), c(3, 5), c(4, 5)) # dd<->f-bi, dd<->pd, dd<->vi, f-bi<->vi, pd<->vi
    )
    # assign values to the groups of transitions
    group_values <- list()
    for (g in seq_along(linked_indices)) {
      for (pair in linked_indices[[g]]) {
        i <- pair[1]
        j <- pair[2]
        masterBlock[i, j] <- counter
      }
      group_values[[g]] <- counter
      counter <- counter + 1
    }

    masterBlock[2, 4] <- NA

    # apply symmetry: masterBlock[i, j] = masterBlock[j, i]
    for (i in 1:d) {
      for (j in 1:d) {
        if (i > j) {
          masterBlock[i, j] <- masterBlock[j, i]
        }
      }
    }

    diag(masterBlock) <- NA

    ### concealed state rates different -----------------------------------------------
    if (diff.conceal == TRUE && all(floor(masterBlock) == masterBlock, na.rm = TRUE) == FALSE) {
      # do something... maybe...
      integersmasterBlock <- floor(masterBlock)
      factorBlock <- signif(masterBlock - integersmasterBlock,
        digits = 2
      )
      factorstoExpand <- unique(sort(c(factorBlock)))
      factorstoExpand <- factorstoExpand[factorstoExpand > 0]
      newshareFac <- (max(factorstoExpand * 10) + 1):(max(factorstoExpand * 10) + length(factorstoExpand))
      newshareFac <- newshareFac / 10
      for (iii in seq_along(newshareFac)) {
        factorBlock[which(factorBlock == factorstoExpand[iii])] <- newshareFac[iii]
      }

      # create defferent id rates for concealed states
      ntraits <- length(sort(unique(traits)))
      uniqParQ <- sort(unique(c(floor(masterBlock))))
      uniqParQ2 <- uniqParQ[which(uniqParQ > 0)]
      concealnewQ <- (max(uniqParQ2) + 1):(max(uniqParQ2) + length(uniqParQ2))
      for (iii in seq_along(concealnewQ)) {
        integersmasterBlock[which(integersmasterBlock == uniqParQ2[iii])] <- concealnewQ[iii]
      }
      concealnewQMatr <- integersmasterBlock + factorBlock

      # fill the q matrix
      Q <- NULL
      for (i in 1:ntraits) {
        Qrow <- NULL
        for (ii in 1:ntraits) {
          entry <- masterBlock[i, ii]
          if (is.na(entry)) {
            Qrow <- cbind(Qrow, masterBlock)
          } else {
            entry <- concealnewQMatr[i, ii]
            outDiagBlock <- matrix(0,
              ncol = ntraits,
              nrow = ntraits, byrow = TRUE
            )
            diag(outDiagBlock) <- entry
            Qrow <- cbind(Qrow, outDiagBlock)
          }
        }
        Q <- rbind(Q, Qrow)
      }
    }

    ### concealed state rates not different ------------------------------------------
    else {
      # create similar id rates for concealed states
      ntraits <- length(sort(unique(traits)))
      uniqParQ <- sort(unique(c(masterBlock)))
      uniqParQ2 <- uniqParQ[which(uniqParQ > 0)]
      concealnewQ <- (max(uniqParQ2) + 1):(max(uniqParQ2) + length(uniqParQ2))
      concealnewQMatr <- masterBlock
      for (I in seq_along(uniqParQ2)) {
        uniqParQ2
        concealnewQMatr[concealnewQMatr == uniqParQ2[I]] <- concealnewQ[I]
      }

      # fill the q matrix
      Q <- NULL
      for (i in 1:ntraits) {
        Qrow <- NULL
        for (ii in 1:ntraits) {
          entry <- masterBlock[i, ii]
          if (is.na(entry)) {
            Qrow <- cbind(Qrow, masterBlock)
          } else {
            if (diff.conceal == TRUE) {
              entry <- concealnewQMatr[i, ii]
            }
            outDiagBlock <- matrix(0,
              ncol = ntraits,
              nrow = ntraits, byrow = TRUE
            )
            diag(outDiagBlock) <- entry
            Qrow <- cbind(Qrow, outDiagBlock)
          }
        }
        Q <- rbind(Q, Qrow)
      }
    }
  }

  ### create and fill Q matrix with Symmetric transition pattern with 2 transition rates -------------
  if (transition == "SYM_2_rates") {
    # create the q matrix
    d <- max(id_rates)
    masterBlock <- matrix(NA, ncol = d, nrow = d, byrow = TRUE)
    # counter for continuous values
    counter <- (max(idparslist[[1]], idparslist[[2]]) + 1)
    # list of transitions sharing the same values
    linked_indices <- list(
      group1 = list(c(1, 2), c(1, 4), c(1, 5), c(1, 3), c(3, 4), c(2, 5)), # bi<->dd, bi<->pd, bi<->vi, bi<->f-bi,  pd<->f-bi, dd<->vi,
      group2 = list(c(2, 3), c(2, 4), c(3, 5), c(4, 5)) # dd<->f-bi, dd<->pd, f-bi<->vi, pd<->vi
    )
    # assign values to the groups of transitions
    group_values <- list()
    for (g in seq_along(linked_indices)) {
      for (pair in linked_indices[[g]]) {
        i <- pair[1]
        j <- pair[2]
        masterBlock[i, j] <- counter
      }
      group_values[[g]] <- counter
      counter <- counter + 1
    }
    # fill in the upper part of the matrix with continuous values
    for (i in 1:d) {
      for (j in 1:d) {
        if (i < j && is.na(masterBlock[i, j])) {
          masterBlock[i, j] <- counter
          counter <- counter + 1
        }
      }
    }
    # apply symmetry: masterBlock[i, j] = masterBlock[j, i]
    for (i in 1:d) {
      for (j in 1:d) {
        if (i > j) {
          masterBlock[i, j] <- masterBlock[j, i]
        }
      }
    }

    diag(masterBlock) <- NA

    ### concealed state rates different -----------------------------------------------
    if (diff.conceal == TRUE && all(floor(masterBlock) == masterBlock, na.rm = TRUE) == FALSE) {
      # do something... maybe...
      integersmasterBlock <- floor(masterBlock)
      factorBlock <- signif(masterBlock - integersmasterBlock,
        digits = 2
      )
      factorstoExpand <- unique(sort(c(factorBlock)))
      factorstoExpand <- factorstoExpand[factorstoExpand > 0]
      newshareFac <- (max(factorstoExpand * 10) + 1):(max(factorstoExpand * 10) + length(factorstoExpand))
      newshareFac <- newshareFac / 10
      for (iii in seq_along(newshareFac)) {
        factorBlock[which(factorBlock == factorstoExpand[iii])] <- newshareFac[iii]
      }

      # create defferent id rates for concealed states
      ntraits <- length(sort(unique(traits)))
      uniqParQ <- sort(unique(c(floor(masterBlock))))
      uniqParQ2 <- uniqParQ[which(uniqParQ > 0)]
      concealnewQ <- (max(uniqParQ2) + 1):(max(uniqParQ2) + length(uniqParQ2))
      for (iii in seq_along(concealnewQ)) {
        integersmasterBlock[which(integersmasterBlock == uniqParQ2[iii])] <- concealnewQ[iii]
      }
      concealnewQMatr <- integersmasterBlock + factorBlock

      # fill the q matrix
      Q <- NULL
      for (i in 1:ntraits) {
        Qrow <- NULL
        for (ii in 1:ntraits) {
          entry <- masterBlock[i, ii]
          if (is.na(entry)) {
            Qrow <- cbind(Qrow, masterBlock)
          } else {
            entry <- concealnewQMatr[i, ii]
            outDiagBlock <- matrix(0,
              ncol = ntraits,
              nrow = ntraits, byrow = TRUE
            )
            diag(outDiagBlock) <- entry
            Qrow <- cbind(Qrow, outDiagBlock)
          }
        }
        Q <- rbind(Q, Qrow)
      }
    }

    ### concealed state rates not different ------------------------------------------
    else {
      # create similar id rates for concealed states
      ntraits <- length(sort(unique(traits)))
      uniqParQ <- sort(unique(c(masterBlock)))
      uniqParQ2 <- uniqParQ[which(uniqParQ > 0)]
      concealnewQ <- (max(uniqParQ2) + 1):(max(uniqParQ2) + length(uniqParQ2))
      concealnewQMatr <- masterBlock
      for (I in seq_along(uniqParQ2)) {
        uniqParQ2
        concealnewQMatr[concealnewQMatr == uniqParQ2[I]] <- concealnewQ[I]
      }

      # fill the q matrix
      Q <- NULL
      for (i in 1:ntraits) {
        Qrow <- NULL
        for (ii in 1:ntraits) {
          entry <- masterBlock[i, ii]
          if (is.na(entry)) {
            Qrow <- cbind(Qrow, masterBlock)
          } else {
            if (diff.conceal == TRUE) {
              entry <- concealnewQMatr[i, ii]
            }
            outDiagBlock <- matrix(0,
              ncol = ntraits,
              nrow = ntraits, byrow = TRUE
            )
            diag(outDiagBlock) <- entry
            Qrow <- cbind(Qrow, outDiagBlock)
          }
        }
        Q <- rbind(Q, Qrow)
      }
    }
  }

  ### create and fill Q matrix with Symmetric transition pattern with 2 transition rates -------------
  if (transition == "SYM_2_rates_plet") {
    # create the q matrix
    d <- max(id_rates)
    masterBlock <- matrix(NA, ncol = d, nrow = d, byrow = TRUE)
    # counter for continuous values
    counter <- (max(idparslist[[1]], idparslist[[2]]) + 1)
    # list of transitions sharing the same values
    linked_indices <- list(
      group1 = list(c(1, 2), c(1, 3), c(1, 4), c(3, 4)), # bi<->dd, bi<->f-bi, bi<->pd, pd<->f-bi
      group2 = list(c(2, 3), c(2, 4)) # dd<->f-bi, dd<->pd
    )
    # assign values to the groups of transitions
    group_values <- list()
    for (g in seq_along(linked_indices)) {
      for (pair in linked_indices[[g]]) {
        i <- pair[1]
        j <- pair[2]
        masterBlock[i, j] <- counter
      }
      group_values[[g]] <- counter
      counter <- counter + 1
    }
    # fill in the upper part of the matrix with continuous values
    for (i in 1:d) {
      for (j in 1:d) {
        if (i < j && is.na(masterBlock[i, j])) {
          masterBlock[i, j] <- counter
          counter <- counter + 1
        }
      }
    }
    # apply symmetry: masterBlock[i, j] = masterBlock[j, i]
    for (i in 1:d) {
      for (j in 1:d) {
        if (i > j) {
          masterBlock[i, j] <- masterBlock[j, i]
        }
      }
    }

    diag(masterBlock) <- NA

    ### concealed state rates different -----------------------------------------------
    if (diff.conceal == TRUE && all(floor(masterBlock) == masterBlock, na.rm = TRUE) == FALSE) {
      # do something... maybe...
      integersmasterBlock <- floor(masterBlock)
      factorBlock <- signif(masterBlock - integersmasterBlock,
        digits = 2
      )
      factorstoExpand <- unique(sort(c(factorBlock)))
      factorstoExpand <- factorstoExpand[factorstoExpand > 0]
      newshareFac <- (max(factorstoExpand * 10) + 1):(max(factorstoExpand * 10) + length(factorstoExpand))
      newshareFac <- newshareFac / 10
      for (iii in seq_along(newshareFac)) {
        factorBlock[which(factorBlock == factorstoExpand[iii])] <- newshareFac[iii]
      }

      # create defferent id rates for concealed states
      ntraits <- length(sort(unique(traits)))
      uniqParQ <- sort(unique(c(floor(masterBlock))))
      uniqParQ2 <- uniqParQ[which(uniqParQ > 0)]
      concealnewQ <- (max(uniqParQ2) + 1):(max(uniqParQ2) + length(uniqParQ2))
      for (iii in seq_along(concealnewQ)) {
        integersmasterBlock[which(integersmasterBlock == uniqParQ2[iii])] <- concealnewQ[iii]
      }
      concealnewQMatr <- integersmasterBlock + factorBlock

      # fill the q matrix
      Q <- NULL
      for (i in 1:ntraits) {
        Qrow <- NULL
        for (ii in 1:ntraits) {
          entry <- masterBlock[i, ii]
          if (is.na(entry)) {
            Qrow <- cbind(Qrow, masterBlock)
          } else {
            entry <- concealnewQMatr[i, ii]
            outDiagBlock <- matrix(0,
              ncol = ntraits,
              nrow = ntraits, byrow = TRUE
            )
            diag(outDiagBlock) <- entry
            Qrow <- cbind(Qrow, outDiagBlock)
          }
        }
        Q <- rbind(Q, Qrow)
      }
    }

    ### concealed state rates not different ------------------------------------------
    else {
      # create similar id rates for concealed states
      ntraits <- length(sort(unique(traits)))
      uniqParQ <- sort(unique(c(masterBlock)))
      uniqParQ2 <- uniqParQ[which(uniqParQ > 0)]
      concealnewQ <- (max(uniqParQ2) + 1):(max(uniqParQ2) + length(uniqParQ2))
      concealnewQMatr <- masterBlock
      for (I in seq_along(uniqParQ2)) {
        uniqParQ2
        concealnewQMatr[concealnewQMatr == uniqParQ2[I]] <- concealnewQ[I]
      }

      # fill the q matrix
      Q <- NULL
      for (i in 1:ntraits) {
        Qrow <- NULL
        for (ii in 1:ntraits) {
          entry <- masterBlock[i, ii]
          if (is.na(entry)) {
            Qrow <- cbind(Qrow, masterBlock)
          } else {
            if (diff.conceal == TRUE) {
              entry <- concealnewQMatr[i, ii]
            }
            outDiagBlock <- matrix(0,
              ncol = ntraits,
              nrow = ntraits, byrow = TRUE
            )
            diag(outDiagBlock) <- entry
            Qrow <- cbind(Qrow, outDiagBlock)
          }
        }
        Q <- rbind(Q, Qrow)
      }
    }
  }

  ### create and fill Q matrix with Symmetric transition pattern with 2 transition rates -------------
  if (transition == "SYM_2_rates_sal") {
    # create the q matrix
    d <- max(id_rates)
    masterBlock <- matrix(NA, ncol = d, nrow = d, byrow = TRUE)
    # counter for continuous values
    counter <- (max(idparslist[[1]], idparslist[[2]]) + 1)
    # list of transitions sharing the same values
    linked_indices <- list(
      group1 = list(c(1, 2), c(1, 3)), # bi<->f-bi, bi<->vi
      group2 = list(c(2, 3)) # f-bi<->vi
    )
    # assign values to the groups of transitions
    group_values <- list()
    for (g in seq_along(linked_indices)) {
      for (pair in linked_indices[[g]]) {
        i <- pair[1]
        j <- pair[2]
        masterBlock[i, j] <- counter
      }
      group_values[[g]] <- counter
      counter <- counter + 1
    }
    # fill in the upper part of the matrix with continuous values
    for (i in 1:d) {
      for (j in 1:d) {
        if (i < j && is.na(masterBlock[i, j])) {
          masterBlock[i, j] <- counter
          counter <- counter + 1
        }
      }
    }
    # apply symmetry: masterBlock[i, j] = masterBlock[j, i]
    for (i in 1:d) {
      for (j in 1:d) {
        if (i > j) {
          masterBlock[i, j] <- masterBlock[j, i]
        }
      }
    }

    diag(masterBlock) <- NA

    ### concealed state rates different -----------------------------------------------
    if (diff.conceal == TRUE && all(floor(masterBlock) == masterBlock, na.rm = TRUE) == FALSE) {
      # do something... maybe...
      integersmasterBlock <- floor(masterBlock)
      factorBlock <- signif(masterBlock - integersmasterBlock,
        digits = 2
      )
      factorstoExpand <- unique(sort(c(factorBlock)))
      factorstoExpand <- factorstoExpand[factorstoExpand > 0]
      newshareFac <- (max(factorstoExpand * 10) + 1):(max(factorstoExpand * 10) + length(factorstoExpand))
      newshareFac <- newshareFac / 10
      for (iii in seq_along(newshareFac)) {
        factorBlock[which(factorBlock == factorstoExpand[iii])] <- newshareFac[iii]
      }

      # create defferent id rates for concealed states
      ntraits <- length(sort(unique(traits)))
      uniqParQ <- sort(unique(c(floor(masterBlock))))
      uniqParQ2 <- uniqParQ[which(uniqParQ > 0)]
      concealnewQ <- (max(uniqParQ2) + 1):(max(uniqParQ2) + length(uniqParQ2))
      for (iii in seq_along(concealnewQ)) {
        integersmasterBlock[which(integersmasterBlock == uniqParQ2[iii])] <- concealnewQ[iii]
      }
      concealnewQMatr <- integersmasterBlock + factorBlock

      # fill the q matrix
      Q <- NULL
      for (i in 1:ntraits) {
        Qrow <- NULL
        for (ii in 1:ntraits) {
          entry <- masterBlock[i, ii]
          if (is.na(entry)) {
            Qrow <- cbind(Qrow, masterBlock)
          } else {
            entry <- concealnewQMatr[i, ii]
            outDiagBlock <- matrix(0,
              ncol = ntraits,
              nrow = ntraits, byrow = TRUE
            )
            diag(outDiagBlock) <- entry
            Qrow <- cbind(Qrow, outDiagBlock)
          }
        }
        Q <- rbind(Q, Qrow)
      }
    }

    ### concealed state rates not different ------------------------------------------
    else {
      # create similar id rates for concealed states
      ntraits <- length(sort(unique(traits)))
      uniqParQ <- sort(unique(c(masterBlock)))
      uniqParQ2 <- uniqParQ[which(uniqParQ > 0)]
      concealnewQ <- (max(uniqParQ2) + 1):(max(uniqParQ2) + length(uniqParQ2))
      concealnewQMatr <- masterBlock
      for (I in seq_along(uniqParQ2)) {
        uniqParQ2
        concealnewQMatr[concealnewQMatr == uniqParQ2[I]] <- concealnewQ[I]
      }

      # fill the q matrix
      Q <- NULL
      for (i in 1:ntraits) {
        Qrow <- NULL
        for (ii in 1:ntraits) {
          entry <- masterBlock[i, ii]
          if (is.na(entry)) {
            Qrow <- cbind(Qrow, masterBlock)
          } else {
            if (diff.conceal == TRUE) {
              entry <- concealnewQMatr[i, ii]
            }
            outDiagBlock <- matrix(0,
              ncol = ntraits,
              nrow = ntraits, byrow = TRUE
            )
            diag(outDiagBlock) <- entry
            Qrow <- cbind(Qrow, outDiagBlock)
          }
        }
        Q <- rbind(Q, Qrow)
      }
    }
  }

  ### create and fill Q matrix with All Rate Different transition pattern -------------
  if (transition == "ARD") {
    # create the q matrix
    d <- max(id_rates)
    masterBlock <- matrix(NA, ncol = d, nrow = d, byrow = TRUE)
    # counter for continuous values
    counter <- (max(idparslist[[1]], idparslist[[2]]) + 1)
    # fill entire matrix (excluding diagonal) with unique continuous values
    for (i in 1:d) {
      for (j in 1:d) {
        if (i != j) {
          masterBlock[i, j] <- counter
          counter <- counter + 1
        }
      }
    }

    diag(masterBlock) <- NA

    ### concealed state rates different -----------------------------------------------
    if (diff.conceal == TRUE && all(floor(masterBlock) == masterBlock, na.rm = TRUE) == FALSE) {
      # do something... maybe...
      integersmasterBlock <- floor(masterBlock)
      factorBlock <- signif(masterBlock - integersmasterBlock,
        digits = 2
      )
      factorstoExpand <- unique(sort(c(factorBlock)))
      factorstoExpand <- factorstoExpand[factorstoExpand > 0]
      newshareFac <- (max(factorstoExpand * 10) + 1):(max(factorstoExpand * 10) + length(factorstoExpand))
      newshareFac <- newshareFac / 10
      for (iii in seq_along(newshareFac)) {
        factorBlock[which(factorBlock == factorstoExpand[iii])] <- newshareFac[iii]
      }

      # create defferent id rates for concealed states
      ntraits <- length(sort(unique(traits)))
      uniqParQ <- sort(unique(c(floor(masterBlock))))
      uniqParQ2 <- uniqParQ[which(uniqParQ > 0)]
      concealnewQ <- (max(uniqParQ2) + 1):(max(uniqParQ2) + length(uniqParQ2))
      for (iii in seq_along(concealnewQ)) {
        integersmasterBlock[which(integersmasterBlock == uniqParQ2[iii])] <- concealnewQ[iii]
      }
      concealnewQMatr <- integersmasterBlock + factorBlock

      # fill the q matrix
      Q <- NULL
      for (i in 1:ntraits) {
        Qrow <- NULL
        for (ii in 1:ntraits) {
          entry <- masterBlock[i, ii]
          if (is.na(entry)) {
            Qrow <- cbind(Qrow, masterBlock)
          } else {
            entry <- concealnewQMatr[i, ii]
            outDiagBlock <- matrix(0,
              ncol = ntraits,
              nrow = ntraits, byrow = TRUE
            )
            diag(outDiagBlock) <- entry
            Qrow <- cbind(Qrow, outDiagBlock)
          }
        }
        Q <- rbind(Q, Qrow)
      }
    }

    ### concealed state rates not different ------------------------------------------
    else {
      # create similar id rates for concealed states
      ntraits <- length(sort(unique(traits)))
      uniqParQ <- sort(unique(c(masterBlock)))
      uniqParQ2 <- uniqParQ[which(uniqParQ > 0)]
      concealnewQ <- (max(uniqParQ2) + 1):(max(uniqParQ2) + length(uniqParQ2))
      concealnewQMatr <- masterBlock
      for (I in seq_along(uniqParQ2)) {
        uniqParQ2
        concealnewQMatr[concealnewQMatr == uniqParQ2[I]] <- concealnewQ[I]
      }

      # fill the q matrix
      Q <- NULL
      for (i in 1:ntraits) {
        Qrow <- NULL
        for (ii in 1:ntraits) {
          entry <- masterBlock[i, ii]
          if (is.na(entry)) {
            Qrow <- cbind(Qrow, masterBlock)
          } else {
            if (diff.conceal == TRUE) {
              entry <- concealnewQMatr[i, ii]
            }
            outDiagBlock <- matrix(0,
              ncol = ntraits,
              nrow = ntraits, byrow = TRUE
            )
            diag(outDiagBlock) <- entry
            Qrow <- cbind(Qrow, outDiagBlock)
          }
        }
        Q <- rbind(Q, Qrow)
      }
    }
  }

  ### add the q matrix to the parameters list -----------------------------------------------
  idparslist[[3]] <- Q

  ### add labels to all matrices and  -------------------------------------------------------
  lab_states <- rep(as.character(sort(unique(traits))), num_concealed_states)
  lab_conceal <- NULL
  for (i in 1:num_concealed_states) {
    lab_conceal <- c(lab_conceal, rep(LETTERS[i], length(sort(unique(traits)))))
  }
  statesCombiNames <- character()
  for (i in 1:length(lab_states)) {
    statesCombiNames <- c(statesCombiNames, paste0(lab_states[i], lab_conceal[i]))
  }

  colnames(idparslist[[1]]) <- statesCombiNames
  colnames(idparslist[[3]]) <- statesCombiNames
  rownames(idparslist[[3]]) <- statesCombiNames

  names(idparslist) <- c("lambdas", "mus", "Q")



  ### save idparslist -----------------------------------------------------------------------
  idparslist_name <- paste0("idparslist_", dependency, "_", inheritance, "_", transition, "_", "fix", parsfix, "_", initparsopt, ".rds")

  if (!is.null(save_dir_idpars)) {
    saveRDS(idparslist, file = file.path(save_dir_idpars, idparslist_name))
  }

  cat("Enregistré :", idparslist_name, "\n")



  ### run secsse ----------------------------------------------------------------------------
  # index some parameters
  num_param_lambda <- length(unique(idparslist[[1]][idparslist[[1]] != 0 & !is.na(idparslist[[1]])]))
  num_param_mu <- length(unique(idparslist[[2]][idparslist[[2]] != 0 & !is.na(idparslist[[2]])]))
  max_id_pars <- max(idparslist$Q, na.rm = TRUE) # our maximum rate parameter
  idparsopt <- sort(unique(unlist(idparslist)))
  idparsopt <- idparsopt[idparsopt > 0]
  num_param_q <- max_id_pars - (num_param_lambda + num_param_mu)

  # initial parameters
  if (initparsopt == "opt") {
    initpars <- c(rep(init_lambda, num_param_lambda), rep(init_mu, num_param_mu), rep(init_q, num_param_q)) # initial parameters - optimised
  }
  if (initparsopt == "opt_x2") {
    initpars <- c(rep(init_lambda * 2, num_param_lambda), rep(init_mu * 2, num_param_mu), rep(init_q * 2, num_param_q)) # initial parameters - optimised * 2
  }
  if (initparsopt == "opt_x0-5") {
    initpars <- c(rep(init_lambda * 0.5, num_param_lambda), rep(init_mu * 0.5, num_param_mu), rep(init_q * 0.5, num_param_q)) # initial parameters - optimised * 0.5
  }
  if (initparsopt == "opt_mu_0-02") {
    initpars <- c(rep(init_lambda, num_param_lambda), rep(0.02, num_param_mu), rep(init_q, num_param_q)) # initial parameters - optimised with mu=0.02
  }

  cat("Nombre de paramètres optimisés:", length(idparsopt), "\n")
  cat("initpars longueur:", length(initpars), "\n")

  # parameters to fix
  if (parsfix == "none") {
    idparsfix <- c(0)
    initparsfix <- c(0.0)
  }

  if (parsfix == "lambda") {
    idparsfix <- c(0, unique(idparslist[[1]][idparslist[[1]] != 0 & !is.na(idparslist[[1]])]))
    initparsfix <- c(0.0, rep(init_lambda, num_param_lambda))
    idparsopt <- idparsopt[!idparsopt %in% as.vector(idparslist[[1]])]
    initpars <- initpars[idparsopt]
  }

  if (parsfix == "mu") {
    idparsfix <- c(0, unique(idparslist[[2]][idparslist[[2]] != 0 & !is.na(idparslist[[2]])]))
    initparsfix <- c(0.0, rep(init_mu, num_param_mu))
    idparsopt <- idparsopt[!idparsopt %in% as.vector(idparslist[[2]])]
    initpars <- initpars[idparsopt]
  }

  # run secsse cla_secsse_ml
  rslts <- secsse::cla_secsse_ml(
    phy = tree,
    traits = traits,
    num_concealed_states = num_concealed_states,
    idparslist = idparslist,
    idparsopt = idparsopt,
    initparsopt = initpars,
    idparsfix = idparsfix,
    parsfix = initparsfix,
    sampling_fraction = sampling_fraction,
    num_threads = num_threads,
    verbose = FALSE
  )

  # number of free parameters
  total_pars <- length(idparsopt)
  names(total_pars) <- "total_free_parameters"

  rslts <- list(
    model_output = rslts,
    total_pars = total_pars,
    parsfix = parsfix,
    init_lambda = init_lambda,
    init_mu = init_mu,
    init_q = init_q,
    initparsopt = initparsopt
  )


  ### save secsse results -----------------------------------------------------------------------
  rslts_name <- paste0("secsse_", dependency, "_", inheritance, "_", transition, "_", "fix", parsfix, "_", initparsopt, ".rds")

  if (!is.null(save_dir_secsse)) {
    saveRDS(rslts, file = file.path(save_dir_secsse, rslts_name))
  }

  cat("Enregistré :", rslts_name, "\n")
}

##### functions to run cla_secsse_timezones_ml ==================================================================

#---------- function to create idparlist

secsse_idparslist <- function(tree, traits, num_concealed_states,
                              dependency, inheritance, transition, diff.conceal) {
  stopifnot(dependency %in% c("ETD", "CTD", "CR"))
  stopifnot(inheritance %in% c("dual_inheritance", "single_inheritance", "dual_symmetric_transition", "dual_asymmetric_transition"))
  stopifnot(transition %in% c("ER", "SYM", "SYM_3_rates", "SYM_2_rates", "ARD"))

  idparslist <- list()
  if (is.matrix(traits)) {
    traits <- traits[, 1]
  }

  num_states <- length(unique(traits))
  ly <- length(sort(unique(traits))) * 2 * num_concealed_states
  d <- ly / 2
  id_rates <- c(1:num_concealed_states)



  ### create lambda and mu matrix ---------------------------------------------------
  # lambda matrix
  idparslist[[1]] <- matrix(0, ncol = d, nrow = 4)
  rownames(idparslist[[1]]) <- c(
    "dual_inheritance",
    "single_inheritance",
    "dual_symmetric_transition",
    "dual_asymmetric_transition"
  )

  # mu matrix
  idparslist[[2]] <- (d + 1):ly

  ### dependency ---------------------------------------------------------------------
  if (dependency == "ETD") {
    ### lambda -----------------------------------------------------------------------
    if (inheritance == "dual_inheritance") {
      idparslist[[1]][1, ] <- rep(id_rates, times = num_concealed_states)
    }
    if (inheritance == "single_inheritance") {
      idparslist[[1]][2, ] <- rep(id_rates, times = num_concealed_states)
    }
    if (inheritance == "dual_symmetric_transition") {
      idparslist[[1]][3, ] <- rep(id_rates, times = num_concealed_states)
    }
    if (inheritance == "dual_asymmetric_transition") {
      idparslist[[1]][4, ] <- rep(id_rates, times = num_concealed_states)
    }
    ### mu ---------------------------------------------------------------------------
    idparslist[[2]][] <- rep(id_rates + length(id_rates), times = num_concealed_states)
  }

  ### dependency ---------------------------------------------------------------------
  if (dependency == "CTD") {
    ### lambda -----------------------------------------------------------------------
    if (inheritance == "dual_inheritance") {
      idparslist[[1]][1, ] <- rep(id_rates, each = num_concealed_states)
    }
    if (inheritance == "single_inheritance") {
      idparslist[[1]][2, ] <- rep(id_rates, each = num_concealed_states)
    }
    if (inheritance == "dual_symmetric_transition") {
      idparslist[[1]][3, ] <- rep(id_rates, each = num_concealed_states)
    }
    if (inheritance == "dual_asymmetric_transition") {
      idparslist[[1]][4, ] <- rep(id_rates, each = num_concealed_states)
    }
    ### mu ---------------------------------------------------------------------------
    idparslist[[2]][] <- rep(id_rates + length(id_rates), each = num_concealed_states)
  }

  ### dependency ---------------------------------------------------------------------
  if (dependency == "CR") {
    ### lambda -----------------------------------------------------------------------
    if (inheritance == "dual_inheritance") {
      idparslist[[1]][1, ] <- rep(1, times = num_concealed_states)
    }
    if (inheritance == "single_inheritance") {
      idparslist[[1]][2, ] <- rep(1, times = num_concealed_states)
    }
    if (inheritance == "dual_symmetric_transition") {
      idparslist[[1]][3, ] <- rep(1, times = num_concealed_states)
    }
    if (inheritance == "dual_asymmetric_transition") {
      idparslist[[1]][4, ] <- rep(1, times = num_concealed_states)
    }
    ### mu ---------------------------------------------------------------------------
    idparslist[[2]][] <- rep(2, times = num_concealed_states)
  }

  ### create and fill Q matrix with Equal Rate transition pattern --------------------
  if (transition == "ER") {
    # create the q matrix
    d <- max(id_rates)
    counter <- (max(idparslist[[1]], idparslist[[2]]) + 1)
    masterBlock <- matrix(counter, ncol = d, nrow = d, byrow = TRUE)
    diag(masterBlock) <- NA

    ### concealed state rates different -----------------------------------------------
    if (diff.conceal == TRUE && all(floor(masterBlock) == masterBlock, na.rm = TRUE) == FALSE) {
      # do something... maybe...
      integersmasterBlock <- floor(masterBlock)
      factorBlock <- signif(masterBlock - integersmasterBlock,
        digits = 2
      )
      factorstoExpand <- unique(sort(c(factorBlock)))
      factorstoExpand <- factorstoExpand[factorstoExpand > 0]
      newshareFac <- (max(factorstoExpand * 10) + 1):(max(factorstoExpand * 10) + length(factorstoExpand))
      newshareFac <- newshareFac / 10
      for (iii in seq_along(newshareFac)) {
        factorBlock[which(factorBlock == factorstoExpand[iii])] <- newshareFac[iii]
      }

      # create defferent id rates for concealed states
      ntraits <- length(sort(unique(traits)))
      uniqParQ <- sort(unique(c(floor(masterBlock))))
      uniqParQ2 <- uniqParQ[which(uniqParQ > 0)]
      concealnewQ <- (max(uniqParQ2) + 1):(max(uniqParQ2) + length(uniqParQ2))
      for (iii in seq_along(concealnewQ)) {
        integersmasterBlock[which(integersmasterBlock == uniqParQ2[iii])] <- concealnewQ[iii]
      }
      concealnewQMatr <- integersmasterBlock + factorBlock

      # fill the q matrix
      Q <- NULL
      for (i in 1:ntraits) {
        Qrow <- NULL
        for (ii in 1:ntraits) {
          entry <- masterBlock[i, ii]
          if (is.na(entry)) {
            Qrow <- cbind(Qrow, masterBlock)
          } else {
            entry <- concealnewQMatr[i, ii]
            outDiagBlock <- matrix(0,
              ncol = ntraits,
              nrow = ntraits, byrow = TRUE
            )
            diag(outDiagBlock) <- entry
            Qrow <- cbind(Qrow, outDiagBlock)
          }
        }
        Q <- rbind(Q, Qrow)
      }
    }

    ### concealed state rates not different ------------------------------------------
    else {
      # create similar id rates for concealed states
      ntraits <- length(sort(unique(traits)))
      uniqParQ <- sort(unique(c(masterBlock)))
      uniqParQ2 <- uniqParQ[which(uniqParQ > 0)]
      concealnewQ <- (max(uniqParQ2) + 1):(max(uniqParQ2) + length(uniqParQ2))
      concealnewQMatr <- masterBlock
      for (I in seq_along(uniqParQ2)) {
        uniqParQ2
        concealnewQMatr[concealnewQMatr == uniqParQ2[I]] <- concealnewQ[I]
      }

      # fill the q matrix
      Q <- NULL
      for (i in 1:ntraits) {
        Qrow <- NULL
        for (ii in 1:ntraits) {
          entry <- masterBlock[i, ii]
          if (is.na(entry)) {
            Qrow <- cbind(Qrow, masterBlock)
          } else {
            if (diff.conceal == TRUE) {
              entry <- concealnewQMatr[i, ii]
            }
            outDiagBlock <- matrix(0,
              ncol = ntraits,
              nrow = ntraits, byrow = TRUE
            )
            diag(outDiagBlock) <- entry
            Qrow <- cbind(Qrow, outDiagBlock)
          }
        }
        Q <- rbind(Q, Qrow)
      }
    }
  }

  ### create and fill Q matrix with Symmetric rate transition pattern -------------
  if (transition == "SYM") {
    # create the q matrix
    d <- max(id_rates)
    masterBlock <- matrix(NA, ncol = d, nrow = d, byrow = TRUE)
    # counter for continuous values
    counter <- (max(idparslist[[1]], idparslist[[2]]) + 1)
    # fill in the upper part of the matrix with continuous values
    for (i in 1:d) {
      for (j in 1:d) {
        if (i < j) { # replace values above diag by those from below
          masterBlock[i, j] <- counter
          counter <- counter + 1
        }
      }
    }
    # apply symmetry: masterBlock[i, j] = masterBlock[j, i]
    for (i in 1:d) {
      for (j in 1:d) {
        if (i > j) {
          masterBlock[i, j] <- masterBlock[j, i]
        }
      }
    }

    diag(masterBlock) <- NA

    ### concealed state rates different -----------------------------------------------
    if (diff.conceal == TRUE && all(floor(masterBlock) == masterBlock, na.rm = TRUE) == FALSE) {
      # do something... maybe...
      integersmasterBlock <- floor(masterBlock)
      factorBlock <- signif(masterBlock - integersmasterBlock,
        digits = 2
      )
      factorstoExpand <- unique(sort(c(factorBlock)))
      factorstoExpand <- factorstoExpand[factorstoExpand > 0]
      newshareFac <- (max(factorstoExpand * 10) + 1):(max(factorstoExpand * 10) + length(factorstoExpand))
      newshareFac <- newshareFac / 10
      for (iii in seq_along(newshareFac)) {
        factorBlock[which(factorBlock == factorstoExpand[iii])] <- newshareFac[iii]
      }

      # create defferent id rates for concealed states
      ntraits <- length(sort(unique(traits)))
      uniqParQ <- sort(unique(c(floor(masterBlock))))
      uniqParQ2 <- uniqParQ[which(uniqParQ > 0)]
      concealnewQ <- (max(uniqParQ2) + 1):(max(uniqParQ2) + length(uniqParQ2))
      for (iii in seq_along(concealnewQ)) {
        integersmasterBlock[which(integersmasterBlock == uniqParQ2[iii])] <- concealnewQ[iii]
      }
      concealnewQMatr <- integersmasterBlock + factorBlock

      # fill the q matrix
      Q <- NULL
      for (i in 1:ntraits) {
        Qrow <- NULL
        for (ii in 1:ntraits) {
          entry <- masterBlock[i, ii]
          if (is.na(entry)) {
            Qrow <- cbind(Qrow, masterBlock)
          } else {
            entry <- concealnewQMatr[i, ii]
            outDiagBlock <- matrix(0,
              ncol = ntraits,
              nrow = ntraits, byrow = TRUE
            )
            diag(outDiagBlock) <- entry
            Qrow <- cbind(Qrow, outDiagBlock)
          }
        }
        Q <- rbind(Q, Qrow)
      }
    }

    ### concealed state rates not different ------------------------------------------
    else {
      # create similar id rates for concealed states
      ntraits <- length(sort(unique(traits)))
      uniqParQ <- sort(unique(c(masterBlock)))
      uniqParQ2 <- uniqParQ[which(uniqParQ > 0)]
      concealnewQ <- (max(uniqParQ2) + 1):(max(uniqParQ2) + length(uniqParQ2))
      concealnewQMatr <- masterBlock
      for (I in seq_along(uniqParQ2)) {
        uniqParQ2
        concealnewQMatr[concealnewQMatr == uniqParQ2[I]] <- concealnewQ[I]
      }

      # fill the q matrix
      Q <- NULL
      for (i in 1:ntraits) {
        Qrow <- NULL
        for (ii in 1:ntraits) {
          entry <- masterBlock[i, ii]
          if (is.na(entry)) {
            Qrow <- cbind(Qrow, masterBlock)
          } else {
            if (diff.conceal == TRUE) {
              entry <- concealnewQMatr[i, ii]
            }
            outDiagBlock <- matrix(0,
              ncol = ntraits,
              nrow = ntraits, byrow = TRUE
            )
            diag(outDiagBlock) <- entry
            Qrow <- cbind(Qrow, outDiagBlock)
          }
        }
        Q <- rbind(Q, Qrow)
      }
    }
  }

  ### create and fill Q matrix with Symmetric transition pattern with 3 transition rates -------------
  if (transition == "SYM_3_rates") {
    # create the q matrix
    d <- max(id_rates)
    masterBlock <- matrix(NA, ncol = d, nrow = d, byrow = TRUE)
    # counter for continuous values
    counter <- (max(idparslist[[1]], idparslist[[2]]) + 1)
    # list of transitions sharing the same values
    linked_indices <- list(
      group1 = list(c(1, 2), c(1, 4), c(1, 5)), # bi<->dd, bi<->pd, bi<->vi,
      group2 = list(c(1, 3), c(3, 4)), # bi<->f-bi and pd<->f-bi
      group3 = list(c(2, 3), c(2, 4), c(2, 5), c(3, 5), c(4, 5)) # dd<->f-bi, dd<->pd, dd<->vi, f-bi<->vi, pd<->vi
    )
    # assign values to the groups of transitions
    group_values <- list()
    for (g in seq_along(linked_indices)) {
      for (pair in linked_indices[[g]]) {
        i <- pair[1]
        j <- pair[2]
        masterBlock[i, j] <- counter
      }
      group_values[[g]] <- counter
      counter <- counter + 1
    }
    # fill in the upper part of the matrix with continuous values
    for (i in 1:d) {
      for (j in 1:d) {
        if (i < j && is.na(masterBlock[i, j])) {
          masterBlock[i, j] <- counter
          counter <- counter + 1
        }
      }
    }
    # apply symmetry: masterBlock[i, j] = masterBlock[j, i]
    for (i in 1:d) {
      for (j in 1:d) {
        if (i > j) {
          masterBlock[i, j] <- masterBlock[j, i]
        }
      }
    }

    diag(masterBlock) <- NA

    ### concealed state rates different -----------------------------------------------
    if (diff.conceal == TRUE && all(floor(masterBlock) == masterBlock, na.rm = TRUE) == FALSE) {
      # do something... maybe...
      integersmasterBlock <- floor(masterBlock)
      factorBlock <- signif(masterBlock - integersmasterBlock,
        digits = 2
      )
      factorstoExpand <- unique(sort(c(factorBlock)))
      factorstoExpand <- factorstoExpand[factorstoExpand > 0]
      newshareFac <- (max(factorstoExpand * 10) + 1):(max(factorstoExpand * 10) + length(factorstoExpand))
      newshareFac <- newshareFac / 10
      for (iii in seq_along(newshareFac)) {
        factorBlock[which(factorBlock == factorstoExpand[iii])] <- newshareFac[iii]
      }

      # create defferent id rates for concealed states
      ntraits <- length(sort(unique(traits)))
      uniqParQ <- sort(unique(c(floor(masterBlock))))
      uniqParQ2 <- uniqParQ[which(uniqParQ > 0)]
      concealnewQ <- (max(uniqParQ2) + 1):(max(uniqParQ2) + length(uniqParQ2))
      for (iii in seq_along(concealnewQ)) {
        integersmasterBlock[which(integersmasterBlock == uniqParQ2[iii])] <- concealnewQ[iii]
      }
      concealnewQMatr <- integersmasterBlock + factorBlock

      # fill the q matrix
      Q <- NULL
      for (i in 1:ntraits) {
        Qrow <- NULL
        for (ii in 1:ntraits) {
          entry <- masterBlock[i, ii]
          if (is.na(entry)) {
            Qrow <- cbind(Qrow, masterBlock)
          } else {
            entry <- concealnewQMatr[i, ii]
            outDiagBlock <- matrix(0,
              ncol = ntraits,
              nrow = ntraits, byrow = TRUE
            )
            diag(outDiagBlock) <- entry
            Qrow <- cbind(Qrow, outDiagBlock)
          }
        }
        Q <- rbind(Q, Qrow)
      }
    }

    ### concealed state rates not different ------------------------------------------
    else {
      # create similar id rates for concealed states
      ntraits <- length(sort(unique(traits)))
      uniqParQ <- sort(unique(c(masterBlock)))
      uniqParQ2 <- uniqParQ[which(uniqParQ > 0)]
      concealnewQ <- (max(uniqParQ2) + 1):(max(uniqParQ2) + length(uniqParQ2))
      concealnewQMatr <- masterBlock
      for (I in seq_along(uniqParQ2)) {
        uniqParQ2
        concealnewQMatr[concealnewQMatr == uniqParQ2[I]] <- concealnewQ[I]
      }

      # fill the q matrix
      Q <- NULL
      for (i in 1:ntraits) {
        Qrow <- NULL
        for (ii in 1:ntraits) {
          entry <- masterBlock[i, ii]
          if (is.na(entry)) {
            Qrow <- cbind(Qrow, masterBlock)
          } else {
            if (diff.conceal == TRUE) {
              entry <- concealnewQMatr[i, ii]
            }
            outDiagBlock <- matrix(0,
              ncol = ntraits,
              nrow = ntraits, byrow = TRUE
            )
            diag(outDiagBlock) <- entry
            Qrow <- cbind(Qrow, outDiagBlock)
          }
        }
        Q <- rbind(Q, Qrow)
      }
    }
  }

  ### create and fill Q matrix with Symmetric transition pattern with 2 transition rates -------------
  if (transition == "SYM_2_rates") {
    # create the q matrix
    d <- max(id_rates)
    masterBlock <- matrix(NA, ncol = d, nrow = d, byrow = TRUE)
    # counter for continuous values
    counter <- (max(idparslist[[1]], idparslist[[2]]) + 1)
    # list of transitions sharing the same values
    linked_indices <- list(
      group1 = list(c(1, 2), c(1, 4), c(1, 5), c(1, 3), c(3, 4), c(2, 5)), # bi<->dd, bi<->pd, bi<->vi, bi<->f-bi,  pd<->f-bi, dd<->vi,
      group2 = list(c(2, 3), c(2, 4), c(3, 5), c(4, 5)) # dd<->f-bi, dd<->pd, f-bi<->vi, pd<->vi
    )
    # assign values to the groups of transitions
    group_values <- list()
    for (g in seq_along(linked_indices)) {
      for (pair in linked_indices[[g]]) {
        i <- pair[1]
        j <- pair[2]
        masterBlock[i, j] <- counter
      }
      group_values[[g]] <- counter
      counter <- counter + 1
    }
    # fill in the upper part of the matrix with continuous values
    for (i in 1:d) {
      for (j in 1:d) {
        if (i < j && is.na(masterBlock[i, j])) {
          masterBlock[i, j] <- counter
          counter <- counter + 1
        }
      }
    }
    # apply symmetry: masterBlock[i, j] = masterBlock[j, i]
    for (i in 1:d) {
      for (j in 1:d) {
        if (i > j) {
          masterBlock[i, j] <- masterBlock[j, i]
        }
      }
    }

    diag(masterBlock) <- NA

    ### concealed state rates different -----------------------------------------------
    if (diff.conceal == TRUE && all(floor(masterBlock) == masterBlock, na.rm = TRUE) == FALSE) {
      # do something... maybe...
      integersmasterBlock <- floor(masterBlock)
      factorBlock <- signif(masterBlock - integersmasterBlock,
        digits = 2
      )
      factorstoExpand <- unique(sort(c(factorBlock)))
      factorstoExpand <- factorstoExpand[factorstoExpand > 0]
      newshareFac <- (max(factorstoExpand * 10) + 1):(max(factorstoExpand * 10) + length(factorstoExpand))
      newshareFac <- newshareFac / 10
      for (iii in seq_along(newshareFac)) {
        factorBlock[which(factorBlock == factorstoExpand[iii])] <- newshareFac[iii]
      }

      # create defferent id rates for concealed states
      ntraits <- length(sort(unique(traits)))
      uniqParQ <- sort(unique(c(floor(masterBlock))))
      uniqParQ2 <- uniqParQ[which(uniqParQ > 0)]
      concealnewQ <- (max(uniqParQ2) + 1):(max(uniqParQ2) + length(uniqParQ2))
      for (iii in seq_along(concealnewQ)) {
        integersmasterBlock[which(integersmasterBlock == uniqParQ2[iii])] <- concealnewQ[iii]
      }
      concealnewQMatr <- integersmasterBlock + factorBlock

      # fill the q matrix
      Q <- NULL
      for (i in 1:ntraits) {
        Qrow <- NULL
        for (ii in 1:ntraits) {
          entry <- masterBlock[i, ii]
          if (is.na(entry)) {
            Qrow <- cbind(Qrow, masterBlock)
          } else {
            entry <- concealnewQMatr[i, ii]
            outDiagBlock <- matrix(0,
              ncol = ntraits,
              nrow = ntraits, byrow = TRUE
            )
            diag(outDiagBlock) <- entry
            Qrow <- cbind(Qrow, outDiagBlock)
          }
        }
        Q <- rbind(Q, Qrow)
      }
    }

    ### concealed state rates not different ------------------------------------------
    else {
      # create similar id rates for concealed states
      ntraits <- length(sort(unique(traits)))
      uniqParQ <- sort(unique(c(masterBlock)))
      uniqParQ2 <- uniqParQ[which(uniqParQ > 0)]
      concealnewQ <- (max(uniqParQ2) + 1):(max(uniqParQ2) + length(uniqParQ2))
      concealnewQMatr <- masterBlock
      for (I in seq_along(uniqParQ2)) {
        uniqParQ2
        concealnewQMatr[concealnewQMatr == uniqParQ2[I]] <- concealnewQ[I]
      }

      # fill the q matrix
      Q <- NULL
      for (i in 1:ntraits) {
        Qrow <- NULL
        for (ii in 1:ntraits) {
          entry <- masterBlock[i, ii]
          if (is.na(entry)) {
            Qrow <- cbind(Qrow, masterBlock)
          } else {
            if (diff.conceal == TRUE) {
              entry <- concealnewQMatr[i, ii]
            }
            outDiagBlock <- matrix(0,
              ncol = ntraits,
              nrow = ntraits, byrow = TRUE
            )
            diag(outDiagBlock) <- entry
            Qrow <- cbind(Qrow, outDiagBlock)
          }
        }
        Q <- rbind(Q, Qrow)
      }
    }
  }

  ### create and fill Q matrix with All Rate Different transition pattern -------------
  if (transition == "ARD") {
    # create the q matrix
    d <- max(id_rates)
    masterBlock <- matrix(NA, ncol = d, nrow = d, byrow = TRUE)
    # counter for continuous values
    counter <- (max(idparslist[[1]], idparslist[[2]]) + 1)
    # fill entire matrix (excluding diagonal) with unique continuous values
    for (i in 1:d) {
      for (j in 1:d) {
        if (i != j) {
          masterBlock[i, j] <- counter
          counter <- counter + 1
        }
      }
    }

    diag(masterBlock) <- NA

    ### concealed state rates different -----------------------------------------------
    if (diff.conceal == TRUE && all(floor(masterBlock) == masterBlock, na.rm = TRUE) == FALSE) {
      # do something... maybe...
      integersmasterBlock <- floor(masterBlock)
      factorBlock <- signif(masterBlock - integersmasterBlock,
        digits = 2
      )
      factorstoExpand <- unique(sort(c(factorBlock)))
      factorstoExpand <- factorstoExpand[factorstoExpand > 0]
      newshareFac <- (max(factorstoExpand * 10) + 1):(max(factorstoExpand * 10) + length(factorstoExpand))
      newshareFac <- newshareFac / 10
      for (iii in seq_along(newshareFac)) {
        factorBlock[which(factorBlock == factorstoExpand[iii])] <- newshareFac[iii]
      }

      # create defferent id rates for concealed states
      ntraits <- length(sort(unique(traits)))
      uniqParQ <- sort(unique(c(floor(masterBlock))))
      uniqParQ2 <- uniqParQ[which(uniqParQ > 0)]
      concealnewQ <- (max(uniqParQ2) + 1):(max(uniqParQ2) + length(uniqParQ2))
      for (iii in seq_along(concealnewQ)) {
        integersmasterBlock[which(integersmasterBlock == uniqParQ2[iii])] <- concealnewQ[iii]
      }
      concealnewQMatr <- integersmasterBlock + factorBlock

      # fill the q matrix
      Q <- NULL
      for (i in 1:ntraits) {
        Qrow <- NULL
        for (ii in 1:ntraits) {
          entry <- masterBlock[i, ii]
          if (is.na(entry)) {
            Qrow <- cbind(Qrow, masterBlock)
          } else {
            entry <- concealnewQMatr[i, ii]
            outDiagBlock <- matrix(0,
              ncol = ntraits,
              nrow = ntraits, byrow = TRUE
            )
            diag(outDiagBlock) <- entry
            Qrow <- cbind(Qrow, outDiagBlock)
          }
        }
        Q <- rbind(Q, Qrow)
      }
    }

    ### concealed state rates not different ------------------------------------------
    else {
      # create similar id rates for concealed states
      ntraits <- length(sort(unique(traits)))
      uniqParQ <- sort(unique(c(masterBlock)))
      uniqParQ2 <- uniqParQ[which(uniqParQ > 0)]
      concealnewQ <- (max(uniqParQ2) + 1):(max(uniqParQ2) + length(uniqParQ2))
      concealnewQMatr <- masterBlock
      for (I in seq_along(uniqParQ2)) {
        uniqParQ2
        concealnewQMatr[concealnewQMatr == uniqParQ2[I]] <- concealnewQ[I]
      }

      # fill the q matrix
      Q <- NULL
      for (i in 1:ntraits) {
        Qrow <- NULL
        for (ii in 1:ntraits) {
          entry <- masterBlock[i, ii]
          if (is.na(entry)) {
            Qrow <- cbind(Qrow, masterBlock)
          } else {
            if (diff.conceal == TRUE) {
              entry <- concealnewQMatr[i, ii]
            }
            outDiagBlock <- matrix(0,
              ncol = ntraits,
              nrow = ntraits, byrow = TRUE
            )
            diag(outDiagBlock) <- entry
            Qrow <- cbind(Qrow, outDiagBlock)
          }
        }
        Q <- rbind(Q, Qrow)
      }
    }
  }

  ### add the q matrix to the parameters list -----------------------------------------------
  idparslist[[3]] <- Q

  ### add labels to all matrices and  -------------------------------------------------------
  lab_states <- rep(as.character(sort(unique(traits))), num_concealed_states)
  lab_conceal <- NULL
  for (i in 1:num_concealed_states) {
    lab_conceal <- c(lab_conceal, rep(LETTERS[i], length(sort(unique(traits)))))
  }
  statesCombiNames <- character()
  for (i in 1:length(lab_states)) {
    statesCombiNames <- c(statesCombiNames, paste0(lab_states[i], lab_conceal[i]))
  }

  colnames(idparslist[[1]]) <- statesCombiNames
  colnames(idparslist[[3]]) <- statesCombiNames
  rownames(idparslist[[3]]) <- statesCombiNames

  names(idparslist) <- c("lambdas", "mus", "Q")

  return(idparslist)
}

#---------- function to create lists of idparlists depending on scenarios

generate_param_combinations <- function(num_timezones,
                                        dependency = c("ETD", "CTD", "CR"),
                                        inheritance = c(
                                          "dual_inheritance", "single_inheritance",
                                          "dual_symmetric_transition", "dual_asymmetric_transition"
                                        ),
                                        transition = c("ER", "SYM", "SYM_3_rates", "SYM_2_rates", "ARD"),
                                        diff.conceal = c(TRUE, FALSE)) {
  # create a grid with all combinations of model parameters
  combos <- expand.grid(
    dependency = dependency,
    inheritance = inheritance,
    transition = transition,
    diff.conceal = diff.conceal,
    stringsAsFactors = FALSE
  )

  # get all combinations of model parameters for N num_timezones
  grid_index <- expand.grid(rep(list(1:nrow(combos)), num_timezones))

  # remove combos with same model parameters
  filtered_index <- grid_index[apply(grid_index, 1, function(row) length(unique(row)) > 1), ]

  # transform into list
  combo_list <- apply(filtered_index, 1, function(row) {
    named_combo <- setNames(
      lapply(seq_along(row), function(j) combos[row[j], ]),
      paste0("time_zone_", seq_along(row))
    )
    return(named_combo)
  })

  return(combo_list)
}

#---------- fucntion to create a list of lists of idparslists with different scenarios

secsse_idparslist_timezones <- function(num_timezones, tree, traits, num_concealed_states,
                                        dependency = c("ETD", "CTD", "CR"),
                                        inheritance = c(
                                          "dual_inheritance",
                                          "single_inheritance",
                                          "dual_symmetric_transition",
                                          "dual_asymmetric_transition"
                                        ),
                                        transition = c("ER", "SYM", "SYM_3_rates", "SYM_2_rates", "ARD"),
                                        diff.conceal = c(TRUE, FALSE)) {
  param_combos <- generate_param_combinations(num_timezones, dependency, inheritance, transition, diff.conceal)

  idparslist_timezones <- lapply(param_combos, function(param_set) {
    # Génère la liste de listes d'idparslist
    idpars_lists <- lapply(param_set, function(params) {
      secsse_idparslist(
        tree = tree,
        traits = traits,
        num_concealed_states = num_concealed_states,
        dependency = params$dependency,
        inheritance = params$inheritance,
        transition = params$transition,
        diff.conceal = params$diff.conceal
      )
    })

    # Applique la modification des idparslist successifs
    for (i in 1:(length(idpars_lists) - 1)) {
      mat_prev <- idpars_lists[[i]][[3]]
      max_val <- max(mat_prev, na.rm = TRUE)

      # Élément 1 (tableau)
      tab <- idpars_lists[[i + 1]][[1]]
      tab[tab != 0] <- tab[tab != 0] + max_val

      # Élément 2 (vecteur)
      vec <- idpars_lists[[i + 1]][[2]]
      vec[vec != 0] <- vec[vec != 0] + max_val

      # Élément 3 (matrice)
      mat <- idpars_lists[[i + 1]][[3]]
      mask <- !is.na(mat) & mat != 0
      mat[mask] <- mat[mask] + max_val

      # Met à jour la liste
      idpars_lists[[i + 1]][[1]] <- tab
      idpars_lists[[i + 1]][[2]] <- vec
      idpars_lists[[i + 1]][[3]] <- mat
    }

    return(idpars_lists)
  })

  return(idparslist_timezones)
}

#---------- function to run cla_secsse_timezones_ml with different scenarios

secsse_timezones_run <- function(tree, traits, num_concealed_states,
                                 idparslist, critical_t,
                                 init_lambda, init_mu, init_q, initparsopt,
                                 parsfix, sampling_fraction,
                                 num_threads) {
  # index parameters
  count_nonzero_unique <- function(x) {
    unique_vals <- unique(as.vector(x))
    sum(!is.na(unique_vals) & unique_vals != 0)
  }

  idparsopt <- sort(unique(unlist(idparslist)))
  idparsopt <- idparsopt[idparsopt > 0]

  # initial parameters
  if (initparsopt == "opt") {
    initpars <- unlist(lapply(idparslist, function(L) {
      lambda_count <- count_nonzero_unique(L[[1]])
      mu_count <- count_nonzero_unique(L[[2]])
      q_count <- count_nonzero_unique(L[[3]])
      c(
        rep(init_lambda, lambda_count),
        rep(init_mu, mu_count),
        rep(init_q, q_count)
      )
    }), use.names = FALSE)
  }
  if (initparsopt == "opt_x2") {
    initpars <- unlist(lapply(idparslist, function(L) {
      lambda_count <- count_nonzero_unique(L[[1]])
      mu_count <- count_nonzero_unique(L[[2]])
      q_count <- count_nonzero_unique(L[[3]])
      c(
        rep(init_lambda * 2, lambda_count),
        rep(init_mu * 2, mu_count),
        rep(init_q * 2, q_count)
      )
    }), use.names = FALSE)
  }
  if (initparsopt == "opt_x0-5") {
    initpars <- unlist(lapply(idparslist, function(L) {
      lambda_count <- count_nonzero_unique(L[[1]])
      mu_count <- count_nonzero_unique(L[[2]])
      q_count <- count_nonzero_unique(L[[3]])
      c(
        rep(init_lambda * 0.5, lambda_count),
        rep(init_mu * 0.5, mu_count),
        rep(init_q * 0.5, q_count)
      )
    }), use.names = FALSE)
  }
  if (initparsopt == "opt_mu_0-02") {
    initpars <- unlist(lapply(idparslist, function(L) {
      lambda_count <- count_nonzero_unique(L[[1]])
      mu_count <- count_nonzero_unique(L[[2]])
      q_count <- count_nonzero_unique(L[[3]])
      c(
        rep(init_lambda, lambda_count),
        rep(0.02, mu_count),
        rep(init_q, q_count)
      )
    }), use.names = FALSE)
  }

  cat("Nombre de paramètres optimisés:", length(idparsopt), "\n")
  cat("initpars longueur:", length(initpars), "\n")

  # parameters to fix
  param_ids <- function(x) {
    unique_vals <- unique(as.vector(x))
    unique_vals <- unique_vals[unique_vals > 0]
  }

  if (parsfix == "none") {
    idparsfix <- c(0)
    initparsfix <- c(0.0)
  }

  if (parsfix == "lambda") {
    id_params_lambda <- unlist(lapply(idparslist, function(L) {
      lambda_ids <- param_ids(L[[1]])
      c(lambda_ids)
    }), use.names = FALSE)
    num_param_lambda <- length(unique(id_params_lambda))

    idparsfix <- c(0, id_params_lambda)
    initparsfix <- c(0.0, rep(init_lambda, num_param_lambda))
    idparsopt <- unlist(lapply(idparslist, function(L) {
      mu_ids <- param_ids(L[[2]])
      q_ids <- param_ids(L[[3]])
      sort(c(mu_ids, q_ids))
    }), use.names = FALSE)
    initpars <- initpars[idparsopt]
  }


  if (parsfix == "mu") {
    id_params_mu <- unlist(lapply(idparslist, function(L) {
      mu_ids <- param_ids(L[[2]])
      c(mu_ids)
    }), use.names = FALSE)
    num_param_mu <- length(unique(id_params_mu))

    idparsfix <- c(0, id_params_mu)
    initparsfix <- c(0.0, rep(init_mu, num_param_mu))
    idparsopt <- unlist(lapply(idparslist, function(L) {
      lambda_ids <- param_ids(L[[1]])
      q_ids <- param_ids(L[[3]])
      sort(c(lambda_ids, q_ids))
    }), use.names = FALSE)
    initpars <- initpars[idparsopt]
  }

  # some other parameters
  tol <- c(1e-04, 1e-05, 1e-07)
  maxiter <- 1000 * round((1.25)^length(idparsopt))
  optimmethod <- "simplex"
  cond <- "proper_cond"
  root_state_weight <- "proper_weights"

  # run secsse_timezones_ml
  rslts <- secsse::cla_secsse_timezones_ml(
    phy = tree,
    traits = traits,
    num_concealed_states = num_concealed_states,
    idparslist = idparslist,
    idparsopt = idparsopt,
    initparsopt = initpars,
    idparsfix = idparsfix,
    parsfix = initparsfix,
    critical_t = critical_t,
    cond = cond,
    root_state_weight = root_state_weight,
    sampling_fraction = sampling_fraction,
    tol = tol,
    maxiter = maxiter,
    optimmethod = optimmethod,
    num_cycles = Inf,
    num_threads = num_threads,
    verbose = FALSE
  )

  # number of free parameters
  total_pars <- length(idparsopt)
  names(total_pars) <- "total_free_parameters"

  rslts <- list(
    model_output = rslts,
    total_pars = total_pars,
    parsfix = parsfix,
    init_lambda = init_lambda,
    init_mu = init_mu,
    init_q = init_q,
    initparsopt = initparsopt
  )

  return(rslts)
}

##### extract parameter values in unfinished models ====================================================================

# function to extract last values of parameters
extract_values <- function(file) {
  # read all the content in one chain
  txt <- readLines(file, warn = FALSE)
  content <- paste(txt, collapse = " ")
  
  # extract all token separated by a space
  tokens <- unlist(strsplit(content, "\\s+"))
  
  # keep the last bloc
  suppressWarnings({
    nums <- as.numeric(tokens)
  })
  
  # identify the last negative value (AIC value)
  neg_idx <- tail(which(nums < 0), 1)
  
  if (length(neg_idx) == 0) {
    return(NA) # if no negative value found
  }
  
  # identify the parameter values (positive decimal values)
  int_idx <- tail(which(!is.na(nums) & nums == floor(nums) & nums >= 0), 1)
  
  values <- NA
  if (length(neg_idx) > 0 && length(int_idx) > 0 && int_idx < neg_idx) {
    values <- nums[(int_idx+1):(neg_idx-1)]
    values <- values[!is.na(values)]
  }
  
  # extract init_mu and init_lambda values
  line_init <- grep("init_mu", txt, value = TRUE)
  
  init_mu <- NA
  init_lambda <- NA
  
  if (length(line_init) > 0) {
    # Regex to extract init values
    matches <- regmatches(line_init, gregexpr("[0-9]+\\.?[0-9eE\\-]*", line_init))
    if (length(matches[[1]]) >= 2) {
      init_mu <- as.numeric(matches[[1]][1])
      init_lambda <- as.numeric(matches[[1]][2])
    }
  }
  
  return(list(values = values, mu = init_mu, lambda = init_lambda))
}

##### function to run cla_secsse_timezones_ml models to finish ========================================================

secsse_timezones_run_to_finish <- function(tree, traits, num_concealed_states,
                                           idparslist, critical_t,
                                           init_lambda, init_mu, init_q, initpars, initparsopt,
                                           parsfix, sampling_fraction,
                                           num_threads) {

  # parameters to fix
  param_ids <- function(x) {
    unique_vals <- unique(as.vector(x))
    unique_vals <- unique_vals[unique_vals > 0]
  }

  if (parsfix == "none") {
    idparsfix <- c(0)
    initparsfix <- c(0.0)
  }

  if (parsfix == "lambda") {
    id_params_lambda <- unlist(lapply(idparslist, function(L) {
      lambda_ids <- param_ids(L[[1]])
      c(lambda_ids)
    }), use.names = FALSE)
    num_param_lambda <- length(unique(id_params_lambda))

    idparsfix <- c(0, id_params_lambda)
    initparsfix <- c(0.0, rep(init_lambda, num_param_lambda))
    idparsopt <- unlist(lapply(idparslist, function(L) {
      mu_ids <- param_ids(L[[2]])
      q_ids <- param_ids(L[[3]])
      sort(c(mu_ids, q_ids))
    }), use.names = FALSE)
    initpars <- initpars[idparsopt]
  }


  if (parsfix == "mu") {
    id_params_mu <- unlist(lapply(idparslist, function(L) {
      mu_ids <- param_ids(L[[2]])
      c(mu_ids)
    }), use.names = FALSE)
    num_param_mu <- length(unique(id_params_mu))

    idparsfix <- c(0, id_params_mu)
    initparsfix <- c(0.0, rep(init_mu, num_param_mu))
    idparsopt <- unlist(lapply(idparslist, function(L) {
      lambda_ids <- param_ids(L[[1]])
      q_ids <- param_ids(L[[3]])
      sort(c(lambda_ids, q_ids))
    }), use.names = FALSE)
    initpars <- initpars[idparsopt]
  }

  # some other parameters
  tol <- c(1e-04, 1e-05, 1e-07)
  maxiter <- 1000 * round((1.25)^length(idparsopt))
  optimmethod <- "simplex"
  cond <- "proper_cond"
  root_state_weight <- "proper_weights"

  # run secsse_timezones_ml
  rslts <- secsse::cla_secsse_timezones_ml(
    phy = tree,
    traits = traits,
    num_concealed_states = num_concealed_states,
    idparslist = idparslist,
    idparsopt = idparsopt,
    initparsopt = initpars,
    idparsfix = idparsfix,
    parsfix = initparsfix,
    critical_t = critical_t,
    cond = cond,
    root_state_weight = root_state_weight,
    sampling_fraction = sampling_fraction,
    tol = tol,
    maxiter = maxiter,
    optimmethod = optimmethod,
    num_cycles = Inf,
    num_threads = num_threads,
    verbose = FALSE
  )

  # number of free parameters
  total_pars <- length(idparsopt)
  names(total_pars) <- "total_free_parameters"

  rslts <- list(
    model_output = rslts,
    total_pars = total_pars,
    parsfix = parsfix,
    init_lambda = init_lambda,
    init_mu = init_mu,
    init_q = init_q,
    initparsopt = initparsopt
  )

  return(rslts)
}